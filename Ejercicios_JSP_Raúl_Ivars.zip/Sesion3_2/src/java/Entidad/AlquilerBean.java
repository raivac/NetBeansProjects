/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;

/**
 *
 * @author raul
 */
public class AlquilerBean {
    
    private String nombrePelicula;
    private String numeroDias;
    private String edadCliente;
    private String formatoPago;
    private String especificaciones;

    /**
     * @return the nombrePelicula
     */
    public String getNombrePelicula() {
        return nombrePelicula;
    }

    /**
     * @param nombrePelicula the nombrePelicula to set
     */
    public void setNombrePelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;
    }

    /**
     * @return the numeroDias
     */
    public String getNumeroDias() {
        return numeroDias;
    }

    /**
     * @param numeroDias the numeroDias to set
     */
    public void setNumeroDias(String numeroDias) {
        this.numeroDias = numeroDias;
    }

    /**
     * @return the edadCliente
     */
    public String getEdadCliente() {
        return edadCliente;
    }

    /**
     * @param edadCliente the edadCliente to set
     */
    public void setEdadCliente(String edadCliente) {
        this.edadCliente = edadCliente;
    }

    /**
     * @return the formatoPago
     */
    public String getFormatoPago() {
        return formatoPago;
    }

    /**
     * @param formatoPago the formatoPago to set
     */
    public void setFormatoPago(String formatoPago) {
        this.formatoPago = formatoPago;
    }

    /**
     * @return the especificaciones
     */
    public String getEspecificaciones() {
        return especificaciones;
    }

    /**
     * @param especificaciones the especificaciones to set
     */
    public void setEspecificaciones(String especificaciones) {
        this.especificaciones = especificaciones;
    }
   
}
